/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 278.5,
        y: 189.6999969482422
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars.myVariable = 0;
    this.vars.xVelocity = 0.47829690000000014;
    this.vars.yVelocity = -7;
    this.vars.lives = 4;
    this.vars.levelNumber = 0;
    this.vars.playerNumber = 1;
    this.vars.PlayersOnline = 0;
    this.vars.P1y = 1;
    this.vars.P1x = 189.6193506489835;
    this.vars.P1b = 0;
    this.vars.P2y = -162;
    this.vars.P2x = 8;
    this.vars.P3x = 8;
    this.vars.P3y = 15;
    this.vars.TimeLeft = 300;
    this.vars.isWaiting = "true";
    this.vars.maxPlayers = 8;
    this.vars.myPlayerSlot = 1;
    this.vars.decodedValue = 0;
    this.vars.encoderDecoderCounter = 3;
    this.vars.idx = -9;
    this.vars.encodedValue = 4.8273414212124323e45;
    this.vars.uc1 = 26;
    this.vars.upperString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    this.vars.textUpperCase = true;
    this.vars.sc1 = 1;
    this.vars.sc2 = 1;
    this.vars.value = 0;
    this.vars.Status = "connected";
    this.vars.P1 = 4.8273414212124323e45;
    this.vars.P2 = 0;
    this.vars.P3 = 0;
    this.vars.P4 = 0;
    this.vars.P5 = 0;
    this.vars.P6 = 0;
    this.vars.P7 = 0;
    this.vars.P8 = 0;
    this.vars.ac1 = 1;
    this.vars.Atc1 = 8;
    this.vars.y = 0;
    this.vars.x = 0;
    this.vars.cloudData = [
      0,
      0,
      5218,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0
    ];
    this.vars.activeCheck = [1, 0, 0, 0, 0, 0, 0, 0];
    this.vars.cloudDataUsername = ["Mryellowdoggy", 0, 0, 0, 0, 0, 0, 0];
    this.vars.numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "_", "-", 0, "."];
    this.vars.chars = [
      "a",
      "b",
      "c",
      "d",
      "e",
      "f",
      "g",
      "h",
      "i",
      "j",
      "k",
      "l",
      "m",
      "n",
      "o",
      "p",
      "q",
      "r",
      "s",
      "t",
      "u",
      "v",
      "w",
      "x",
      "y",
      "z",
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H",
      "I",
      "J",
      "K",
      "L",
      "M",
      "N",
      "O",
      "P",
      "Q",
      "R",
      "S",
      "T",
      "U",
      "V",
      "W",
      "X",
      "Y",
      "Z",
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9,
      "_",
      "-",
      0,
      0,
      "."
    ];
    this.vars.upperChars = [
      "A",
      "B",
      "C",
      "D",
      "E",
      "F",
      "G",
      "H",
      "I",
      "J",
      "K",
      "L",
      "M",
      "N",
      "O",
      "P",
      "Q",
      "R",
      "S",
      "T",
      "U",
      "V",
      "W",
      "X",
      "Y",
      "Z"
    ];
    this.vars.splitResults = [0];
    this.vars.lastValue = [1635, 0, 0, 0, 0, 0, 0, 0];
  }
}
