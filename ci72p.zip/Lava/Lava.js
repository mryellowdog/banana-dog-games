/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Lava extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume14", "./Lava/costumes/costume14.svg", {
        x: 280.75,
        y: -172.14999389648438
      }),
      new Costume("costume2", "./Lava/costumes/costume2.svg", {
        x: 280.75,
        y: -169.49787500000002
      }),
      new Costume("costume3", "./Lava/costumes/costume3.svg", {
        x: 280.75,
        y: -172.14999389648438
      }),
      new Costume("costume4", "./Lava/costumes/costume4.svg", {
        x: 280.75,
        y: -172.14999389648438
      }),
      new Costume("costume5", "./Lava/costumes/costume5.svg", {
        x: 280.75,
        y: -172.14999389648438
      }),
      new Costume("costume6", "./Lava/costumes/costume6.svg", {
        x: 280.75,
        y: -172.14999389648438
      }),
      new Costume("costume7", "./Lava/costumes/costume7.svg", {
        x: 280.75,
        y: -172.14999389648438
      }),
      new Costume("costume8", "./Lava/costumes/costume8.svg", {
        x: 280.75,
        y: 180.75000343302492
      }),
      new Costume("costume9", "./Lava/costumes/costume9.svg", {
        x: 292.5,
        y: 180.75000343302492
      }),
      new Costume("costume10", "./Lava/costumes/costume10.svg", {
        x: 292.5,
        y: 180.75000343302492
      }),
      new Costume("costume11", "./Lava/costumes/costume11.svg", {
        x: 292.5,
        y: 180.75000343302492
      })
    ];

    this.sounds = [new Sound("pop", "./Lava/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "NEXT LEVEL" },
        this.whenIReceiveNextLevel
      )
    ];

    this.vars.level4 = 1;
  }

  *whenGreenFlagClicked() {
    /* TODO: Implement looks_gotofrontback */ null;
    this.costume = "costume14";
  }

  *whenGreenFlagClicked2() {}

  *whenIReceiveNextLevel() {
    this.costumeNumber += 1;
  }
}
