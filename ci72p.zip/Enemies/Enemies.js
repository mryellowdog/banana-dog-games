/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Enemies extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume14", "./Enemies/costumes/costume14.svg", {
        x: 280.75,
        y: -111.69860999999997
      }),
      new Costume("costume2", "./Enemies/costumes/costume2.svg", {
        x: 280.75,
        y: -100.35964000000001
      }),
      new Costume("costume3", "./Enemies/costumes/costume3.svg", {
        x: 280.75,
        y: 18.8749999999998
      }),
      new Costume("costume4", "./Enemies/costumes/costume4.svg", {
        x: 280.75,
        y: -100.35964000000001
      }),
      new Costume("costume5", "./Enemies/costumes/costume5.svg", {
        x: 280.75,
        y: -111.69860999999997
      }),
      new Costume("costume6", "./Enemies/costumes/costume6.svg", {
        x: 280.75,
        y: -100.35964000000001
      }),
      new Costume("costume7", "./Enemies/costumes/costume7.svg", {
        x: 280.75,
        y: -100.35964000000001
      }),
      new Costume("costume10", "./Enemies/costumes/costume10.svg", {
        x: 280.75,
        y: -100.35964000000001
      }),
      new Costume("costume8", "./Enemies/costumes/costume8.svg", {
        x: 280.75,
        y: 18.880844999999994
      }),
      new Costume("costume9", "./Enemies/costumes/costume9.svg", {
        x: 280.75,
        y: -111.69860999999997
      }),
      new Costume("costume11", "./Enemies/costumes/costume11.svg", {
        x: 280.75,
        y: -49.99999999999994
      })
    ];

    this.sounds = [new Sound("pop", "./Enemies/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "NEXT LEVEL" },
        this.whenIReceiveNextLevel
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.BROADCAST, { name: "start" }, this.whenIReceiveStart)
    ];

    this.vars.level5 = 1;
  }

  *whenGreenFlagClicked() {
    this.costume = "costume14";
    this.x = -20;
  }

  *whenGreenFlagClicked2() {}

  *whenIReceiveNextLevel() {
    this.costumeNumber += 1;
    this.goto(0, 8);
  }

  *whenGreenFlagClicked3() {
    while (true) {
      this.x += -1;
      yield;
    }
  }

  *whenIReceiveStart() {
    this.goto(0, 8);
    while (true) {
      this.y = -10;
      yield;
    }
  }
}
