/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Player1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "ddxh2tf-fc8fc42e-8794-4501-8621-31a4e68a25b5",
        "./Player1/costumes/ddxh2tf-fc8fc42e-8794-4501-8621-31a4e68a25b5.png",
        { x: 200, y: 200 }
      ),
      new Costume(
        "ddxh2tf-fc8fc42e-8794-4501-8621-31a4e68a25b52",
        "./Player1/costumes/ddxh2tf-fc8fc42e-8794-4501-8621-31a4e68a25b52.png",
        { x: 200, y: 200 }
      ),
      new Costume(
        "ddxh2tf-fc8fc42e-8794-4501-8621-31a4e68a25b53",
        "./Player1/costumes/ddxh2tf-fc8fc42e-8794-4501-8621-31a4e68a25b53.png",
        { x: 200, y: 200 }
      )
    ];

    this.sounds = [
      new Sound("pop", "./Player1/sounds/pop.wav"),
      new Sound(
        "Alan Walker - Faded [mp3clan].mp3",
        "./Player1/sounds/Alan Walker - Faded [mp3clan].mp3.wav"
      ),
      new Sound(
        "TheFatRat+-+Time+Lapse",
        "./Player1/sounds/TheFatRat+-+Time+Lapse.wav"
      ),
      new Sound(
        "Vexento - Tevo (Original Mix)",
        "./Player1/sounds/Vexento - Tevo (Original Mix).wav"
      ),
      new Sound("Super Mario Bros", "./Player1/sounds/Super Mario Bros.mp3"),
      new Sound("smb_powerup", "./Player1/sounds/smb_powerup.wav"),
      new Sound("smb_mariodie", "./Player1/sounds/smb_mariodie.wav"),
      new Sound("smb_jump-small", "./Player1/sounds/smb_jump-small.wav"),
      new Sound("smb_gameover", "./Player1/sounds/smb_gameover.wav"),
      new Sound("smb_1-up", "./Player1/sounds/smb_1-up.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.KEY_PRESSED, { key: "b" }, this.whenKeyBPressed),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked6),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked7),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked8),
      new Trigger(Trigger.BROADCAST, { name: "start" }, this.whenIReceiveStart),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked9),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked10),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked11),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked12),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked13),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked14),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked15),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked16),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked17),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked18)
    ];

    this.vars.xVelocity2 = 0;
    this.vars.yVelocity2 = 0;
    this.vars.level = 466;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.stage.vars.y = 0;
    this.stage.vars.x = 0;
    this.goto(this.stage.vars.x, this.stage.vars.y);
  }

  *whenGreenFlagClicked2() {}

  *whenGreenFlagClicked3() {
    this.visible = true;
  }

  *whenGreenFlagClicked4() {
    this.size = 50;
    while (true) {
      if (this.touching(Color.rgb(255, 0, 0))) {
        if (this.size == 70) {
          this.size = 50;
        } else {
          yield* this.startSound("smb_mariodie");
          this.goto(-194, 2);
          this.stage.vars.lives += -1;
        }
      }
      if (this.touching(Color.rgb(121, 85, 72))) {
        if (this.size == 70) {
          this.size = 50;
        } else {
          this.goto(-194, 2);
          yield* this.startSound("smb_mariodie");
          this.stage.vars.lives += -1;
        }
      }
      if (this.touching(this.sprites["Powerup"].andClones())) {
        yield* this.startSound("smb_powerup");
        this.size = 70;
      }
      if (this.touching(Color.rgb(233, 219, 25))) {
        if (this.size == 70) {
          this.size = 50;
        } else {
          this.goto(-194, 2);
          yield* this.startSound("smb_mariodie");
          this.stage.vars.lives += -1;
        }
      }
      if (this.touching(Color.rgb(76, 175, 80))) {
        this.stage.vars.lives += 1;
        yield* this.startSound("smb_1-up");
        yield* this.wait(5);
      }
      if (this.touching(Color.rgb(255, 152, 61))) {
        this.goto(-194, 2);
        yield* this.startSound("smb_mariodie");
        this.stage.vars.lives += -1;
      }
      yield;
    }
  }

  *whenKeyBPressed() {
    this.broadcast("NEXT LEVEL");
  }

  *whenGreenFlagClicked5() {
    this.goto(-194, 2);
  }

  *whenGreenFlagClicked6() {
    while (true) {
      if (this.keyPressed("any")) {
        this.costumeNumber += 1;
        yield* this.wait(0.1);
      }
      yield;
    }
  }

  *whenGreenFlagClicked7() {
    this.stage.vars.lives = 3;
    while (true) {
      if (this.stage.vars.lives < 0) {
        null;
      }
      yield;
    }
  }

  *whenGreenFlagClicked8() {
    while (true) {
      if (this.stage.vars.lives < 0) {
        /* TODO: Implement stop other scripts in sprite */ null;
        this.stopAllSounds();
        yield* this.startSound("smb_gameover");
        this.goto(8, 139);
        for (let i = 0; i < 10; i++) {
          this.y += 10;
          yield;
        }
        for (let i = 0; i < 10; i++) {
          this.y += -20;
          yield;
        }
        yield* this.wait(3);
        /* TODO: Implement stop all */ null;
      }
      yield;
    }
  }

  *whenIReceiveStart() {
    yield* this.playSoundUntilDone("Super Mario Bros");
  }

  *whenGreenFlagClicked9() {
    while (true) {
      null;
      yield;
    }
  }

  *whenGreenFlagClicked10() {
    if (this.stage.vars.playerNumber == 1) {
      this.stage.vars.yVelocity = 0;
      this.stage.vars.xVelocity = 0;
      this.goto(-194, 2);
      while (true) {
        if (this.keyPressed("right arrow")) {
          this.stage.vars.xVelocity += 1;
        }
        if (this.keyPressed("left arrow")) {
          this.stage.vars.xVelocity += -1;
        }
        this.stage.vars.xVelocity = this.stage.vars.xVelocity * 0.9;
        this.x += this.stage.vars.xVelocity;
        if (this.touching(this.sprites["Level"].andClones())) {
          this.y += 1;
          if (this.touching(this.sprites["Level"].andClones())) {
            this.y += 1;
            if (this.touching(this.sprites["Level"].andClones())) {
              this.y += 1;
              if (this.touching(this.sprites["Level"].andClones())) {
                this.y += 1;
                if (this.touching(this.sprites["Level"].andClones())) {
                  this.y += 1;
                  if (this.touching(this.sprites["Level"].andClones())) {
                    this.x += this.stage.vars.xVelocity * -1;
                    this.y += -5;
                  }
                }
              }
            }
          }
        }
        this.stage.vars.yVelocity += -1;
        this.y += this.stage.vars.yVelocity;
        if (this.touching(this.sprites["Level"].andClones())) {
          this.y += this.stage.vars.yVelocity * -1;
          this.stage.vars.yVelocity = 0;
        }
        this.y += -1;
        if (this.touching(this.sprites["Level"].andClones())) {
          if (this.keyPressed("up arrow")) {
            this.stage.vars.yVelocity += 15;
            yield* this.startSound("smb_jump-small");
          }
        }
        this.y += 1;
        if (this.x > 230) {
          this.vars.level += 1;
          this.stage.vars.yVelocity = 0;
          this.stage.vars.xVelocity = 0;
          this.goto(-194, 2);
          this.broadcast("NEXT LEVEL");
        }
        yield;
      }
    }
  }

  *whenGreenFlagClicked11() {
    if (null) {
      null;
    }
  }

  *whenGreenFlagClicked12() {}

  *whenGreenFlagClicked13() {
    while (true) {
      if (!this.keyPressed("any")) {
        this.stage.vars.isWaiting = "true";
        yield* this.wait(10);
        if (this.stage.vars.isWaiting == "true") {
          this.stage.vars.PlayersOnline += -1;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked14() {
    while (true) {
      this.restartTimer();
      yield;
    }
  }

  *whenGreenFlagClicked15() {
    if (this.timer > 0.1) {
      null;
    }
  }

  *whengreaterthan() {
    while (true) {
      if (!this.keyPressed("any")) {
        this.stage.vars.isWaiting = "true";
        yield* this.wait(10);
        if (this.stage.vars.isWaiting == "true") {
          this.stage.vars.PlayersOnline += -1;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked16() {
    while (true) {
      if (0 > this.stage.vars.PlayersOnline) {
        this.stage.vars.PlayersOnline = 0;
      }
      yield;
    }
  }

  *whenGreenFlagClicked17() {}

  *whengreaterthan2() {
    while (true) {
      if (0 > this.stage.vars.PlayersOnline) {
        this.stage.vars.PlayersOnline = 0;
      }
      yield;
    }
  }

  *whenGreenFlagClicked18() {
    yield* this.wait(1);
    yield* this.playSoundUntilDone("Super Mario Bros");
  }
}
