/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Maxresdefault2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "maxresdefault (2)",
        "./Maxresdefault2/costumes/maxresdefault (2).png",
        { x: 480, y: 298 }
      ),
      new Costume(
        "45e5547c962be626df28067b29e9a48e",
        "./Maxresdefault2/costumes/45e5547c962be626df28067b29e9a48e.png",
        { x: 480, y: 21 }
      )
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenthisspriteclicked() {
    this.broadcast("start");
    this.visible = false;
  }

  *whenGreenFlagClicked() {
    /* TODO: Implement looks_gotofrontback */ null;
    this.visible = true;
  }
}
