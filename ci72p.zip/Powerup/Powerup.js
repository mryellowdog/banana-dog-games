/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Powerup extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "f1e65dd24607f2f2",
        "./Powerup/costumes/f1e65dd24607f2f2.png",
        { x: 0, y: 0 }
      ),
      new Costume("f1e65dd24607f2f", "./Powerup/costumes/f1e65dd24607f2f.png", {
        x: 360,
        y: 360
      }),
      new Costume(
        "f1e65dd24607f2f3",
        "./Powerup/costumes/f1e65dd24607f2f3.png",
        { x: 360, y: 360 }
      )
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "NEXT LEVEL" },
        this.whenIReceiveNextLevel
      )
    ];
  }

  *whenIReceiveNextLevel() {
    this.costumeNumber += 1;
  }
}
