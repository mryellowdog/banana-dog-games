import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Player1 from "./Player1/Player1.js";
import Level from "./Level/Level.js";
import Lava from "./Lava/Lava.js";
import Enemies from "./Enemies/Enemies.js";
import Powerup from "./Powerup/Powerup.js";
import Maxresdefault2 from "./Maxresdefault2/Maxresdefault2.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Player1: new Player1({
    x: -189.30467209999998,
    y: -26,
    direction: 90,
    costumeNumber: 2,
    size: 70,
    visible: true
  }),
  Level: new Level({
    x: 0,
    y: 8,
    direction: 90,
    costumeNumber: 6,
    size: 100,
    visible: true
  }),
  Lava: new Lava({
    x: 0,
    y: 8,
    direction: 90,
    costumeNumber: 6,
    size: 100,
    visible: true
  }),
  Enemies: new Enemies({
    x: -7,
    y: -10,
    direction: 90,
    costumeNumber: 6,
    size: 100,
    visible: true
  }),
  Powerup: new Powerup({
    x: 132,
    y: -67,
    direction: 90,
    costumeNumber: 2,
    size: 10,
    visible: true
  }),
  Maxresdefault2: new Maxresdefault2({
    x: -3,
    y: -2,
    direction: 90,
    costumeNumber: 1,
    size: 125,
    visible: false
  })
};

const project = new Project(stage, sprites);
export default project;
