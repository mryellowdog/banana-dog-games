/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Level extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume16", "./Level/costumes/costume16.svg", {
        x: 280.5,
        y: -58.001920290399994
      }),
      new Costume("costume2", "./Level/costumes/costume2.svg", {
        x: 280.5,
        y: -35.00191555519996
      }),
      new Costume("costume3", "./Level/costumes/costume3.svg", {
        x: 280.5,
        y: 8.99808999999999
      }),
      new Costume("costume4", "./Level/costumes/costume4.svg", {
        x: 280.5,
        y: -86
      }),
      new Costume("costume5", "./Level/costumes/costume5.svg", {
        x: 280.5,
        y: -109.00191000000001
      }),
      new Costume("costume6", "./Level/costumes/costume6.svg", {
        x: 280.5,
        y: 68.00077141380004
      }),
      new Costume("costume7", "./Level/costumes/costume7.svg", {
        x: 280.5,
        y: -170.39999999999998
      }),
      new Costume("costume8", "./Level/costumes/costume8.svg", {
        x: 280.5,
        y: -10.001914999999997
      }),
      new Costume("costume9", "./Level/costumes/costume9.svg", {
        x: 280.5,
        y: 82.79808305175729
      }),
      new Costume("costume10", "./Level/costumes/costume10.svg", {
        x: 280.5,
        y: -49.00191680424274
      }),
      new Costume("costume11", "./Level/costumes/costume11.svg", {
        x: 280.5,
        y: -31.001930000000016
      }),
      new Costume("costume12", "./Level/costumes/costume12.svg", {
        x: 280.5,
        y: 155.47736130882265
      })
    ];

    this.sounds = [new Sound("pop", "./Level/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "NEXT LEVEL" },
        this.whenIReceiveNextLevel
      )
    ];

    this.vars.level2 = 1;
    this.vars.xVelocity3 = 0;
    this.vars.yVelocity3 = 0;
    this.vars.level3 = 0;
  }

  *whenGreenFlagClicked() {
    this.costume = "costume16";
  }

  *whenGreenFlagClicked2() {}

  *whenIReceiveNextLevel() {
    this.costumeNumber += 1;
  }
}
